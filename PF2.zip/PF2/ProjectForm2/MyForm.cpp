#include "MyForm.h"
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <time.h>
#include <math.h>

//#define pop_size		2000		// ������ ���������
#define max_iteration	16000	    // ������������ ����� ��������
//#define elitrate		0.10		// �����������
//#define mutation_rate	0.25		// �������
//#define mutation		RAND_MAX * mutation_rate
//#define end_target		std::string("World")

//using namespace std;
using namespace System;
using namespace System::Windows::Forms;

//�����
/*public ref*/ struct individual
{
	std::string str;						// ������
	unsigned int fitness;		    // �����������
};

typedef std::vector <individual> ind;

// ������� ����������� ���������
void init_population(ind& population, ind& offspring, int pop_size, std::string end_target)
{
	int tsize = end_target.size();

	for (int i = 0; i < pop_size; i++)
	{
		individual citizen;

		citizen.fitness = 0;
		citizen.str.erase();

		for (int j = 0; j < tsize; j++)
		{
			citizen.str += (rand() % 220) + 34;
		}

		population.push_back(citizen);
	}

	offspring.resize(pop_size);
}

// ������ �����������������
void calc_fitness(ind& population, int pop_size, std::string end_target)
{
	std::string target = end_target;
	int tsize = target.size();
	unsigned int fitness;

	for (int i = 0; i < pop_size; i++)
	{
		fitness = 0;

		for (int j = 0; j < tsize; j++)
		{
			fitness += abs(int(population[i].str[j] - target[j]));
		}

		population[i].fitness = fitness;
	}
}

// ��������� �����������������
bool fitness_sort(individual x, individual y)
{
	return (x.fitness < y.fitness);
}

// ���������� ������ �� �� ����������������� (�� �������� � ��������)
inline void sort_by_fitness(ind& population)
{
	sort(population.begin(), population.end(), fitness_sort);
}

// �������� ��������� ������ � ��������� ���������
void elitism(ind& population, ind& offspring, int esize)
{
	for (int i = 0; i < esize; i++)
	{
		offspring[i].str = population[i].str;
		offspring[i].fitness = population[i].fitness;
	}
}

// �������
void mutate(individual& member, std::string end_target)
{
	int tsize = end_target.size();
	int ipos = rand() % tsize;
	int delta = (rand() % 220) + 34;

	member.str[ipos] = ((member.str[ipos] + delta) % 122);
}

// ����������� ������
void cross(ind& population, ind& offspring, int pop_size, double elitrate, double mutation, std::string end_target)
{
	int esize = pop_size * elitrate;
	int tsize = end_target.size() , spos, i1, i2;

	elitism(population, offspring, esize);

	for (int i = esize; i < pop_size; i++)
	{
		i1 = rand() % (pop_size / 2);
		i2 = rand() % (pop_size / 2);
		spos = rand() % tsize;

		offspring[i].str = population[i1].str.substr(0, spos) + population[i2].str.substr(spos, esize - spos);

		if (rand() < mutation) mutate(offspring[i], end_target);
	}
}

// ����� �������� ��������������� ����� �������� ���������
//inline void print_best(ind& gav)
//{
//	if (gav[0].fitness != 0)
//	{
//		cout << gav[0].str << " (" << gav[0].fitness << ")" << endl;
//	}
//	else
//	{
//		textBox2->AppendText(end_target1);
//		//cout << gav[0].str << endl;
//	}
//}

inline void swap(ind*& population, ind*& offspring)
{
	ind* temp = population;
	population = offspring;
	offspring = temp;
}

void MarshalString(String^ s, std::string& os)
{
	using namespace Runtime::InteropServices;
	const char* chars =
		(const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
	os = chars;
	Marshal::FreeHGlobal(IntPtr((void*)chars));
}

[STAThreadAttribute]
void main(array<String^>^ args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	ProjectForm2::MyForm form;
	Application::Run(% form);

	setlocale(LC_ALL, "russian");
	srand(unsigned(time(NULL)));
}

System::Void ProjectForm2::MyForm::button1_Click(System::Object^ sender, System::EventArgs^ e)
{
	int pop_size;
	double elitrate, mutation_rate, mutation;
	pop_size = Convert::ToInt32(tb_pop_size->Text);
	//pop_size = 2000;
	//elitrate = Convert::ToDouble(tb_elitrate->Text);
	elitrate = double::Parse(tb_elitrate->Text);
	//elitrate = 0,10;
	mutation_rate = Convert::ToDouble(tb_mutation_rate->Text);
	mutation_rate = 0.25;
	mutation = RAND_MAX * mutation_rate;
	String^ end_target1 = Convert::ToString(tb_word->Text);
	std::string end_target;
	MarshalString(end_target1, end_target);

	//gt = end_target1->Length;
	//textBox2->AppendText(Convert::ToString(gt));
	//for (int i = 0; i < 10; i++)
	//{
	//	//textBox2->AppendText("generation: ");
	//	textBox2->Text += "generation: " + end_target1 + "\r" + "\n";
	//	//textBox2->AppendText(end_target1);
	//	//textBox2->AppendText("\n");
	//}

	textBox2->Clear();
	chart1->Series[0]->Points->Clear();
	ind pop_alpha, pop_beta;
	ind* population, * offspring;

	init_population(pop_alpha, pop_beta, pop_size, end_target);
	population = &pop_alpha;
	offspring = &pop_beta;

	bool p;
	int x, y;

	for (int i = 0; i < max_iteration; i++)
	{
		calc_fitness(*population, pop_size, end_target);
		sort_by_fitness(*population);

		//cout << i + 1 << " generation: ";
		textBox2->AppendText(Convert::ToString(i + 1));
		textBox2->AppendText(" generation: ");

		//print_best(*population);
		if ((*population)[0].fitness != 0)
		{
			//textBox2->AppendText("\r");
			//textBox2->AppendText("\n");
			//textBox2->Text += "generation: " + end_target1 + "\r" + "\n";
			// 
			//cout << gav[0].str << " (" << gav[0].fitness << ")" << endl;
			String^ str2 = gcnew String((*population)[0].str.c_str());
			textBox2->AppendText(str2);
			textBox2->AppendText(" (");
			textBox2->AppendText(Convert::ToString((*population)[0].fitness));
			textBox2->AppendText(")");
			textBox2->Text += "\r" + "\n";
			delete str2;
			
			//���������� �������
			x = i+1;
			y = (*population)[0].fitness;
			chart1->Series[0]->Points->AddXY(x, y);

		}
		else
		{			
			//cout << gav[0].str << endl;
			String^ str2 = gcnew String((*population)[0].str.c_str());
			textBox2->AppendText(str2);	
			textBox2->Text += "\r" + "\n";			
			delete str2;

			//���������� �������
			x = i+1;
			y = (*population)[0].fitness;
			chart1->Series[0]->Points->AddXY(x, y);
		}

		if ((*population)[0].fitness == 0) break;

		cross(*population, *offspring, pop_size, elitrate, mutation, end_target);
		swap(population, offspring);
	}	
	return System::Void();
}

System::Void ProjectForm2::MyForm::button2_Click(System::Object^ sender, System::EventArgs^ e)
{
	Application::Exit();
	return System::Void();
}

System::Void ProjectForm2::MyForm::textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e)
{
	chart1->Series[0]->Points->Clear();
	textBox2->Clear();
	return System::Void();
}

System::Void ProjectForm2::MyForm::btn_random_Click(System::Object^ sender, System::EventArgs^ e)
{
	int pop, mult;
	pop += (rand() % 5000) + 500;
	tb_pop_size->Clear();
	tb_pop_size->AppendText(Convert::ToString(pop));
	double elit, mutat;
	mult = (rand() % 50) + 1;
	elit = (0.01 * mult);
	tb_elitrate->Clear();
	tb_elitrate->AppendText(Convert::ToString(elit));
	mult = (rand() % 99) + 1;
	mutat = (0.01 * mult);
	tb_mutation_rate->Clear();
	tb_mutation_rate->AppendText(Convert::ToString(mutat));
	tb_word->Clear();
	tb_word->AppendText(Convert::ToString("���"));
	return System::Void();
}




