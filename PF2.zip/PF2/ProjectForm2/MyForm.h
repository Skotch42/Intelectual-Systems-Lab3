#pragma once

namespace ProjectForm2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ btnStart;
	private: System::Windows::Forms::TextBox^ tb_pop_size;
	protected:

	protected:

	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::Button^ btnExit;
	private: System::Windows::Forms::Label^ lbl_pop_size;
	private: System::Windows::Forms::Label^ lbl_elitrate;
	private: System::Windows::Forms::TextBox^ tb_elitrate;
	private: System::Windows::Forms::Label^ lbl_mutation_rate;
	private: System::Windows::Forms::TextBox^ tb_mutation_rate;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^ chart1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ tb_word;
	private: System::Windows::Forms::Button^ btn_random;







	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Legend^ legend1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Legend());
			System::Windows::Forms::DataVisualization::Charting::Series^ series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			this->btnStart = (gcnew System::Windows::Forms::Button());
			this->tb_pop_size = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->btnExit = (gcnew System::Windows::Forms::Button());
			this->lbl_pop_size = (gcnew System::Windows::Forms::Label());
			this->lbl_elitrate = (gcnew System::Windows::Forms::Label());
			this->tb_elitrate = (gcnew System::Windows::Forms::TextBox());
			this->lbl_mutation_rate = (gcnew System::Windows::Forms::Label());
			this->tb_mutation_rate = (gcnew System::Windows::Forms::TextBox());
			this->chart1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tb_word = (gcnew System::Windows::Forms::TextBox());
			this->btn_random = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->BeginInit();
			this->SuspendLayout();
			// 
			// btnStart
			// 
			this->btnStart->Location = System::Drawing::Point(632, 477);
			this->btnStart->Name = L"btnStart";
			this->btnStart->Size = System::Drawing::Size(75, 23);
			this->btnStart->TabIndex = 0;
			this->btnStart->Text = L"Start";
			this->btnStart->UseVisualStyleBackColor = true;
			this->btnStart->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// tb_pop_size
			// 
			this->tb_pop_size->Location = System::Drawing::Point(717, 63);
			this->tb_pop_size->Name = L"tb_pop_size";
			this->tb_pop_size->Size = System::Drawing::Size(100, 22);
			this->tb_pop_size->TabIndex = 1;
			this->tb_pop_size->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox1_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(554, 250);
			this->textBox2->Multiline = true;
			this->textBox2->Name = L"textBox2";
			this->textBox2->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox2->Size = System::Drawing::Size(263, 190);
			this->textBox2->TabIndex = 2;
			// 
			// btnExit
			// 
			this->btnExit->Location = System::Drawing::Point(742, 477);
			this->btnExit->Name = L"btnExit";
			this->btnExit->Size = System::Drawing::Size(75, 23);
			this->btnExit->TabIndex = 4;
			this->btnExit->Text = L"Exit";
			this->btnExit->UseVisualStyleBackColor = true;
			this->btnExit->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// lbl_pop_size
			// 
			this->lbl_pop_size->AutoSize = true;
			this->lbl_pop_size->Location = System::Drawing::Point(552, 68);
			this->lbl_pop_size->Name = L"lbl_pop_size";
			this->lbl_pop_size->Size = System::Drawing::Size(136, 17);
			this->lbl_pop_size->TabIndex = 5;
			this->lbl_pop_size->Text = L"������ ���������:\r\n";
			// 
			// lbl_elitrate
			// 
			this->lbl_elitrate->AutoSize = true;
			this->lbl_elitrate->Location = System::Drawing::Point(551, 107);
			this->lbl_elitrate->Name = L"lbl_elitrate";
			this->lbl_elitrate->Size = System::Drawing::Size(97, 17);
			this->lbl_elitrate->TabIndex = 6;
			this->lbl_elitrate->Text = L"�����������:";
			// 
			// tb_elitrate
			// 
			this->tb_elitrate->Location = System::Drawing::Point(717, 102);
			this->tb_elitrate->Name = L"tb_elitrate";
			this->tb_elitrate->Size = System::Drawing::Size(100, 22);
			this->tb_elitrate->TabIndex = 7;
			// 
			// lbl_mutation_rate
			// 
			this->lbl_mutation_rate->AutoSize = true;
			this->lbl_mutation_rate->Location = System::Drawing::Point(551, 150);
			this->lbl_mutation_rate->Name = L"lbl_mutation_rate";
			this->lbl_mutation_rate->Size = System::Drawing::Size(156, 17);
			this->lbl_mutation_rate->TabIndex = 8;
			this->lbl_mutation_rate->Text = L"����������� �������:\r\n";
			// 
			// tb_mutation_rate
			// 
			this->tb_mutation_rate->Location = System::Drawing::Point(717, 145);
			this->tb_mutation_rate->Name = L"tb_mutation_rate";
			this->tb_mutation_rate->Size = System::Drawing::Size(100, 22);
			this->tb_mutation_rate->TabIndex = 9;
			// 
			// chart1
			// 
			chartArea1->Name = L"ChartArea1";
			this->chart1->ChartAreas->Add(chartArea1);
			legend1->Enabled = false;
			legend1->Name = L"Legend1";
			this->chart1->Legends->Add(legend1);
			this->chart1->Location = System::Drawing::Point(33, 63);
			this->chart1->Name = L"chart1";
			series1->BorderWidth = 2;
			series1->ChartArea = L"ChartArea1";
			series1->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Line;
			series1->Color = System::Drawing::Color::Red;
			series1->IsVisibleInLegend = false;
			series1->Legend = L"Legend1";
			series1->Name = L"Series1";
			this->chart1->Series->Add(series1);
			this->chart1->Size = System::Drawing::Size(482, 377);
			this->chart1->TabIndex = 10;
			this->chart1->Text = L"chart1";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(552, 230);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(238, 17);
			this->label1->TabIndex = 11;
			this->label1->Text = L"������ ������������� ���������\r\n";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(30, 43);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(194, 17);
			this->label2->TabIndex = 12;
			this->label2->Text = L"������ �����������������";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(551, 184);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(147, 17);
			this->label3->TabIndex = 13;
			this->label3->Text = L"����������� �����: \r\n";			
			// 
			// tb_word
			// 
			this->tb_word->Location = System::Drawing::Point(717, 184);
			this->tb_word->Name = L"tb_word";
			this->tb_word->Size = System::Drawing::Size(100, 22);
			this->tb_word->TabIndex = 14;
			// 
			// btn_random
			// 
			this->btn_random->Location = System::Drawing::Point(526, 477);
			this->btn_random->Name = L"btn_random";
			this->btn_random->Size = System::Drawing::Size(75, 23);
			this->btn_random->TabIndex = 15;
			this->btn_random->Text = L"Random\r\n";
			this->btn_random->UseVisualStyleBackColor = true;
			this->btn_random->Click += gcnew System::EventHandler(this, &MyForm::btn_random_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(854, 512);
			this->Controls->Add(this->btn_random);
			this->Controls->Add(this->tb_word);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->chart1);
			this->Controls->Add(this->tb_mutation_rate);
			this->Controls->Add(this->lbl_mutation_rate);
			this->Controls->Add(this->tb_elitrate);
			this->Controls->Add(this->lbl_elitrate);
			this->Controls->Add(this->lbl_pop_size);
			this->Controls->Add(this->btnExit);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->tb_pop_size);
			this->Controls->Add(this->btnStart);
			this->Name = L"MyForm";
			this->Text = L"������������ ��������";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e);
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e);
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e);
	private: System::Void btn_random_Click(System::Object^ sender, System::EventArgs^ e);
};
}
